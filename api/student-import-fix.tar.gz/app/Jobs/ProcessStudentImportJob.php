<?php

namespace App\Jobs;

use App\Events\StudentActivated;
use App\Http\Middleware\SetPostgresSessionTenant;
use App\Models\ImportJob;
use App\Models\Student;
use App\Models\User;
use App\Support\Imports\StudentImportColumns;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Spatie\SimpleExcel\SimpleExcelReader;
use Throwable;

class ProcessStudentImportJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public ImportJob $importJob) {}

    public function handle(): void
    {
        $job = $this->importJob->fresh();

        if (! $job || $job->status === 'Completed') {
            return;
        }

        $job->forceFill(['status' => 'Processing'])->save();

        try {
            $this->processSheet($job);

            $job->forceFill([
                'status' => 'Completed',
                'committed_at' => now(),
            ])->save();
        } catch (Throwable $exception) {
            $job->forceFill([
                'status' => 'Failed',
                'meta' => array_merge($job->meta ?? [], [
                    'error' => $exception->getMessage(),
                ]),
            ])->save();

            throw $exception;
        }
    }

    private function processSheet(ImportJob $job): void
    {
        // Set tenant session for RLS
        SetPostgresSessionTenant::setTenantSessionVariable($job->tenant_id);

        $path = Storage::disk('local')->path($job->filename);
        $reader = SimpleExcelReader::create($path);

        $inserted = 0;

        DB::transaction(function () use ($reader, $job, &$inserted): void {
            foreach ($reader->getRows() as $row) {
                $data = $this->normalizeRow($row);

                // Minimal safety: required fields should already be validated in dry-run
                foreach (StudentImportColumns::requiredHeaders() as $required) {
                    if (blank($data[$required] ?? null)) {
                        throw new \RuntimeException(sprintf('Row missing required field %s after dry-run.', $required));
                    }
                }

                $studentUid = $data['student_uid'] ?? null;
                if (blank($studentUid)) {
                    $studentUid = Student::generateStudentUid($job->tenant_id);
                }

                $mapId = $data['map_id'] ?? null;
                if (blank($mapId)) {
                    $mapId = Student::generateMapStudentId($job->tenant_id);
                }

                $dob = null;
                if (! empty($data['date_of_birth'])) {
                    $dob = \Illuminate\Support\Carbon::parse($data['date_of_birth']);
                }

                $user = User::create([
                    'tenant_id' => $job->tenant_id,
                    'name' => $data['full_name'],
                    'email' => $data['email_address'],
                    'phone' => $data['mobile_number'],
                    'gender' => strtolower($data['gender'] ?? ''),
                    'dob' => $dob,
                    'password' => Hash::make('Student@123'),
                    'kind' => 'student',
                    'is_active' => false,
                ]);

                $user->assignRole('Student');

                $student = Student::query()->create([
                    'tenant_id' => $job->tenant_id,
                    'user_id' => $user->id,
                    'full_name' => $data['full_name'],
                    'map_student_id' => $mapId,
                    'erp_number' => $data['erp_number'] ?? null,
                    'department' => $data['department'] ?? null,
                    'year_of_study' => $data['year_of_study'] ?? null,
                    'mobile_number' => $data['mobile_number'],
                    'email_address' => $data['email_address'],
                    'father_name' => $data['father_name'] ?? null,
                    'father_mobile_number' => $data['father_mobile_number'] ?? null,
                    'mother_name' => $data['mother_name'] ?? null,
                    'mother_mobile_number' => $data['mother_mobile_number'] ?? null,
                    'local_guardian_name' => $data['local_guardian_name'] ?? null,
                    'local_guardian_contact' => $data['local_guardian_contact'] ?? null,
                    'local_relationship' => $data['local_relationship'] ?? null,
                    'local_address' => $data['local_address'] ?? null,
                    'blood_group' => $data['blood_group'] ?? null,
                    'medical_information' => $data['medical_information'] ?? null,
                ]);

                // Force-fill fields not in $fillable (gender, dob, student_uid)
                $student->forceFill([
                    'student_uid' => $studentUid,
                    'gender' => strtolower($data['gender'] ?? ''),
                    'date_of_birth' => $dob,
                ])->save();

                event(new StudentActivated($student));
                $inserted++;
            }
        });

        $job->forceFill([
            'inserted_rows' => $inserted,
            'updated_rows' => 0,
            'processed_rows' => $inserted,
            'meta' => array_merge($job->meta ?? [], [
                'inserted' => $inserted,
            ]),
        ])->save();
    }

    /**
     * Normalize row keys to snake_case headers and trim values.
     */
    private function normalizeRow(array $row): array
    {
        return StudentImportColumns::normalizeRow($row);
    }
}
